$(document).ready(function () {
    //for jquery functions

});


//for custom javascript functions function


